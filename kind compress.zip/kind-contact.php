<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.2.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.2.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets-kind/images/logo5.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Register</title>
  <link rel="stylesheet" href="assets-kind/tether/tether.min.css">
  <link rel="stylesheet" href="assets-kind/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets-kind/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets-kind/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets-kind/formstyler/jquery.formstyler.css">
  <link rel="stylesheet" href="assets-kind/formstyler/jquery.formstyler.theme.css">
  <link rel="stylesheet" href="assets-kind/datepicker/jquery.datetimepicker.min.css">
  <link rel="stylesheet" href="assets-kind/theme/css/style.css">
  <link rel="preload" as="style" href="assets-kind/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets-kind/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<body>
  
  <section class="form5 cid-sUxHbQuSNy" id="form5-9">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Become our Partner!</strong></h3>
            
        </div>
        <div class="row justify-content-center mt-4">
            <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                <form action="https://mobirise.eu/" method="POST" class="mbr-form form-with-styler" data-form-title="Form Name"><input type="hidden" name="email" data-form-email="true" value="Cwm5WdUV1jRE52OryCI87TQCA9zzaGyzartcQscaitojJbRQfuGM5Pty5vhlJkuyflJ/ur6BNXAp5iSardb57Y1Bg8UNjKHmtr+YFjh1TaK1KARS+jfOvMjlYvQk/DlD">
                    <div class="">
                        <div hidden="hidden" data-form-alert="" class="alert alert-success col-12">Thanks for filling out
                            the form!</div>
                        <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">Oops...! some
                            problem!</div>
                    </div>
                    <div class="dragArea row">
                        <div class="col-md col-sm-12 form-group" data-for="name">
                            <input type="text" name="name" placeholder="Name" data-form-field="name" class="form-control" value="" id="name-form5-9">
                        </div>
                        <div class="col-md col-sm-12 form-group" data-for="email">
                            <input type="email" name="email" placeholder="E-mail" data-form-field="email" class="form-control" value="" id="email-form5-9">
                        </div>
                        <div class="col-12 form-group" data-for="url">
                            <input type="url" name="url" placeholder="Your Site" data-form-field="url" class="form-control" value="" id="url-form5-9">
                        </div>
                        <div class="col-12 form-group" data-for="textarea">
                            <textarea name="textarea" placeholder="Message" data-form-field="textarea" class="form-control" id="textarea-form5-9"></textarea>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 align-center mbr-section-btn"><button type="submit" class="btn btn-secondary display-4">Send message</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/z" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;">Start your own site - <a href="https://mobirise.site/v" style="color:#aaa;">Go here</a></p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/formstyler/jquery.formstyler.js"></script>  <script src="assets/formstyler/jquery.formstyler.min.js"></script>  <script src="assets/datepicker/jquery.datetimepicker.full.js"></script>  <script src="assets/theme/js/script.js"></script>  <script src="assets/formoid/formoid.min.js"></script>  
  
  
</body>
</html>