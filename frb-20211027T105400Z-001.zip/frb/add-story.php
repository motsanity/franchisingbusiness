<?php
	require_once("db.php");

		
	$target_dir = "uploads/stories/";
	$target_file = $target_dir . basename($_FILES["story_image"]["name"]);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	// Check if image file is a actual image or fake image
	if(isset($_POST["submit"])) {
	  $check = getimagesize($_FILES["story_image"]["tmp_name"]);
	  if($check !== false) {
	    echo "File is an image - " . $check["mime"] . ".";
	    $uploadOk = 1;

	  } else {
	    echo "File is not an image.";
	    $uploadOk = 0;
	  }
	}

	// Check if file already exists
	if (file_exists($target_file)) {
	  echo "Sorry, file already exists.";
	  $uploadOk = 0;
	}

	// Check file size
	if ($_FILES["story_image"]["size"] > 2000000) { // 20MB
	  echo "Sorry, your file is too large.";
	  $uploadOk = 0;
	}

	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
	  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
	  $uploadOk = 0;
	}

	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
	  echo "Sorry, your file was not uploaded.";

	  $url = $_SERVER["REQUEST_URI"];
	  $current = explode('?', explode('/', $url)[count(explode('/', $url)) - 1])[1];
	  session_start();
	  $_SESSION["file_error"] = 1; 
	  die(header("Location: profile.php?" . $current));
	// if everything is ok, try to upload file
	} else {
	  if (move_uploaded_file($_FILES["story_image"]["tmp_name"], $target_file)) {
	    echo "The file ". htmlspecialchars( basename( $_FILES["story_image"]["name"])). " has been uploaded.";

		$fi = $_REQUEST["id"];
		$t = $_POST['story_title'];
		$i = $target_file;
		$d = $_POST["story_description"];

		$stm = $conn->prepare("INSERT INTO stories(franchisee_id, image, title, description) VALUES(:fi, :i, :t, :d)");

		if ($stm->execute(array(':fi' => $fi, ':i' => $i, ':t' => $t, ':d' => $d))) {
			session_start();
			//$_SESSION["uh"] =  1;
			die(header("Location: profile.php?id=" . $fi));
		}
		else {
			session_start();
			//$_SESSION["uh"] =  0;
			die(header("Location: profile.php?id=" . $fi));
		}

	  } else {
	    echo "Sorry, there was an error uploading your file.";
	  }
	}

?>