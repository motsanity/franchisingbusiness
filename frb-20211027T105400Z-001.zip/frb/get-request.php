<?php

	if (!isset($_REQUEST["id"])){
		$url = $_SERVER["PHP_SELF"];
		$current = explode('/', $url)[count(explode('/', $url)) - 1];
		die(header("Location: " . $current . "?id=00510835"));
	}
?>