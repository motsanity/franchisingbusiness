<!DOCTYPE html>
<html>
<?php 
    include("get-request.php");
?>
<head>
    <title>Franchising Business | How to Franchise</title>
    <?php
        include("component/head_assets.html");
    ?>
    <style>
    	<?php
        include("component/video_css.css");
    ?>
</style>
</head>
<body>
<?php
  include("fetch-active-webinar.php");
  foreach ($result as $v) {
    $video = $v->video;
    # code...
  }
?>
<header>
  <div class="overlay"></div>
  <video playsinline="playsinline"  muted="false" id="webinar" poster="assets/images/black.png">
    <source src="<?php echo $video; ?>" type="video/mp4">
    Your browser cannot play the video.	
  </video>
</header>
<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="height: 200px">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hi, brave dreamer!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Would you like to avail a franchise now?
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-warning register" data-target="client-register.php?id=<?php echo $_REQUEST['id'];?>">Yes!</button>
        <button type="button" class="btn btn-dark close" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="videoModalReplay" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="height: 200px">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hi, brave dreamer!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Would you like to avail a franchise now?
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-warning register" data-target="client-register.php?id=<?php echo $_REQUEST['id'];?>">Yes!</button>
        <button type="button" class="btn btn-dark close" data-dismiss="modal" id="replayButton">Replay video</button>
      </div>
    </div>
  </div>
</div>


<?php
    include("component/footer.php");

?>
</section>
<?php
    include("component/footer_assets.html");
?>   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
	$(function(){
		var lapsed = false;
		
		function toggleOpenModal(){
			$('#videoModal').modal("show"); 
		}
		function toggleOpenModalReplay(){
			$('#videoModalReplay').modal("show"); 
		}
		function toggleCloseModal(){
			$('#videoModal').modal("hide"); 
			$('#videoModalReplay').modal("hide");
		}
		$('.close').on("click", function(){
			toggleCloseModal();
		});

		$("#webinar").on("ended", function(){
			toggleOpenModalReplay();
		});

		$("#replayButton").on("click", function(){
			$("#webinar").get(0).play();
			initTimer(10000); // shorter time
		})
		$(".register").on("click", function(){
			var url = $(this).data("target")
			location.replace(url);
		});

		initTimer(900000); // 15 minutes

		function initTimer(t){
			var modalTimer = setInterval(function(){
			toggleOpenModal();
			lapsed = true;

			if (lapsed)
				clearInterval(modalTimer);
			}, t);
		}
		$("#webinar").get(0).play();
	})
</script>	
</body>
</html>