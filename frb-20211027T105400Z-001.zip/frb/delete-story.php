<?php
	require_once("db.php");

	$fi = $_REQUEST["id"];
	$pi = $_REQUEST["post_id"];


	$stm_get = $conn->prepare("select image as i from stories where id = :pi");
	$stm_get->execute(array(':pi' => $pi));
	$result = $stm_get->fetchAll(PDO::FETCH_OBJ);

	foreach ($result as $r) {
		$image_url = $r->i;
	}

	$stm = $conn->prepare("DELETE FROM stories WHERE id = :pi");

	if ($stm->execute(array(':pi' => $pi))) {
		// DELETE IMAGE IN STORAGE
		$file_pointer = $image_url; 
   
		// Use unlink() function to delete a file 
		if (!unlink($file_pointer)) { 
		    echo ("$file_pointer cannot be deleted due to an error"); 
		} 
		else { 
		    echo ("$file_pointer has been deleted"); 
		} 

		session_start();
		//$_SESSION["uh"] =  1;
		die(header("Location: profile.php?id=" . $fi));
	}
	else {
		session_start();
		//$_SESSION["uh"] =  0;
		die(header("Location: profile.php?id=" . $fi));
	}

?>