<?php
  session_start();
  if (!isset($_SESSION["r"]) || $_SESSION["r"] != 2) {
    $_SESSION["r"] = 0; // bad access
    die (header("Location: login.php"));
  }
?>