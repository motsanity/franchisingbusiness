<?php
$target_dir = "uploads/headlines/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["image"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;

  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["image"]["size"] > 2000000) { // 20MB
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
    
  $url = $_SERVER["REQUEST_URI"];
  $current = explode('?', explode('/', $url)[count(explode('/', $url)) - 1])[1];
  session_start();
  $_SESSION["file_error"] = 1; 
  die(header("Location: profile.php?" . $current));

// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.";

    require_once("db.php");

	$fi = $_REQUEST["id"];
	$im = $target_file;

  $stm = $conn->prepare("SELECT image from headlines where franchisee_id = :fi");
  $stm->execute(array(':fi' => $fi));
  $result = $stm->fetchAll(PDO::FETCH_OBJ);
  foreach ($result as $r){
    $file_pointer = $r->image; 
   
    // Use unlink() function to delete a file 
    if (!unlink($file_pointer)) { 
        echo ("$file_pointer cannot be deleted due to an error"); 
    } 
    else { 
        echo ("$file_pointer has been deleted"); 
    } 
  }


	$stm = $conn->prepare("INSERT INTO headlines(franchisee_id, image) VALUES(:fi, :im) ON DUPLICATE KEY UPDATE image = :im");

	if ($stm->execute(array(':fi' => $fi, ':im' => $im, ':im' => $im))) {
		session_start();
		//$_SESSION["uh"] =  1;
		die(header("Location: profile.php?id=" . $fi));
	}
	else {
		session_start();
		//$_SESSION["uh"] =  0;
		die(header("Location: profile.php?id=" . $fi));
	}


  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>

?>