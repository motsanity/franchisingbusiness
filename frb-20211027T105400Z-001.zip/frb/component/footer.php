
<section data-bs-version="5.1" class="footer3 cid-sMEQ4catHM" once="footers" id="footer3-14">
    <div class="container">
        <div class="media-container-row align-center mbr-white">  
            <div class="row row-copirayt">
                <p class="mbr-text mb-0 mbr-fonts-style mbr-white align-center">
                    © Copyright <?php echo date("Y") ?> Franchising Business. All Rights Reserved.
                </p>
            </div>
        </div>
    </div>
</section>