<?php

	require_once("db.php");

	$id = $_REQUEST["id"];
	$fn = $_POST["firstname"];
	$mn = $_POST["middlename"];
	$ln = $_POST["lastname"];
	$ad = $_POST["address"];
	$bd = $_POST["birthdate"];
	$em = $_POST["email"];
	$ph = $_POST["phone"];

	$stm = $conn->prepare("INSERT INTO client (franchisee_id, first_name, middle_name, last_name, address, birthdate, email, phone) VALUES(:id, :fn, :mn, :ln, :ad, :bd, :em, :ph)");

	if ($stm->execute(array(':id' => $id, ':fn' => $fn, ':mn' => $mn, ':ln' => $ln, ':ad' => $ad, ':bd' => $bd, ':em' => $em, ':ph' => $ph))) {
		session_start();
		$_SESSION["g"] =  1;
		die(header("Location: client-register.php?id=" . $id));
	}
	else {
		session_start();
		$_SESSION["g"] =  0;
		die(header("Location: client-register.php?id=" . $id));
	}


?>