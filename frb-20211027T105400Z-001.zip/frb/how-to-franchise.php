<!DOCTYPE html>
<html>
<?php 
    include("get-request.php");
?>
<head>
    <title>Franchising Business | How to Franchise</title>
    <?php
        include("component/head_assets.html");
    ?>
</head>
<body>
<?php
    include("component/navbar-client.php");
    $fi = $_REQUEST["id"];
?>
<section data-bs-version="5.1" class="header6 cid-sMEM3YRg1F mbr-fullscreen" id="header6-11">
    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);"></div>
    <div class="align-center container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <h1 class="mbr-section-title mbr-fonts-style mbr-white mb-3 display-1"><strong>Online Franchise Business</strong></h1>
                
                <p class="mbr-text mbr-white mbr-fonts-style display-7">
                    A business that you can start and operate at the comfort of your own home!</p>
                <div class="mbr-section-btn mt-3"><a class="btn btn-black display-4" href="watch-video.php?id=<?php echo $fi; ?>" target="_blank">Watch video now!</a></div>
            </div>
        </div>
    </div>
</section>
<?php
    include("component/footer.php");

?>
</section>
<?php
    include("component/footer_assets.html");
?>   
</body>
</html>